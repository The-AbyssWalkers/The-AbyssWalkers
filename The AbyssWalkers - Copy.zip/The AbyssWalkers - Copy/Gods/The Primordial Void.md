Void before time
