Blood food: 
Blood cake etc, they eat food made from blood.

Blood Farms