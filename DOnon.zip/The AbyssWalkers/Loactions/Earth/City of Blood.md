Ruled by House Bloodborne

City formed by blood sacrifice to The Everbleeding. 

The walls are white and red, made of bone and flesh.
