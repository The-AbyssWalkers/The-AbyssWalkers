Void before time and existence 
