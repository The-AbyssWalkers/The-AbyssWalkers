White Bridges and Spires, and a lot of Crest of Everlight

lot of illuminous lamps

build in volcano with death monster

Lot of Cathedrals

Paladin Guardians

made out of corpse of Monster

Towers around the city with Everlight, keeping monsters out

Skull is the throne room